import {readFile} from 'node:fs/promises';
import pg from 'pg';
const url=process.env.MIGRATION_DATABASE_URL||process.env.DATABASE_URL;
if(!url)throw Error('Set DATABASE_URL or MIGRATION_DATABASE_URL first.');
const client=new pg.Client({connectionString:url});
await client.connect();
try {
 await client.query('BEGIN');
 await client.query('SELECT pg_advisory_xact_lock(813701)');
 await client.query('CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
 for(const name of ['001_initial.sql']){
  const applied=await client.query('SELECT name FROM schema_migrations WHERE name=$1',[name]);
  if(!applied.rowCount){await client.query(await readFile(new URL('../db/'+name,import.meta.url),'utf8'));await client.query('INSERT INTO schema_migrations(name) VALUES($1)',[name]);console.log('Applied '+name);}
 }
 await client.query('COMMIT');
 console.log('Database ready.');
}catch(e){await client.query('ROLLBACK');throw e}finally{await client.end()}
