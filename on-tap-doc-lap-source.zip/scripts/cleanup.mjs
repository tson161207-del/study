import {getPool} from '../lib/db.mjs';
const db=getPool();
try {
 await db.query('DELETE FROM sessions WHERE expires_at < now()');
 await db.query('DELETE FROM auth_limits WHERE bucket < $1',[Math.floor(Date.now()/900000)-96]);
 console.log('Expired sessions and old rate-limit counters removed.');
}finally{await db.end()}
