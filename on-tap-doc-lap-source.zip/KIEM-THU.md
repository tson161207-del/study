# Kết quả kiểm tra bản độc lập — 04/11/2026

Đã đạt:
- Next.js production build, bao gồm TypeScript.
- npm run typecheck.
- 4 nhóm kiểm thử tự động (npm test), bao gồm PostgreSQL nhúng PGlite:
  mật khẩu có salt, xác thực đúng/sai, trùng email, phiên hết hạn/thu hồi,
  CRUD đề, sửa hồ sơ, phân quyền hai tài khoản, rate limiting,
  CSRF Origin, dữ liệu không hợp lệ và payload quá lớn.
- HTTP production trên localhost: trang chủ 200, thư viện khách ẩn danh,
  từ chối Origin giả (403), từ chối đăng ký sai dữ liệu (400).
- Kiểm tra gói standalone có node-postgres; không còn mã tích hợp Sites/ChatGPT/D1.

Giới hạn xác minh:
- Máy hiện tại không có Docker hoặc PostgreSQL server ngoài; chưa chạy Docker Compose,
  chưa chạy test HTTP toàn luồng với PostgreSQL server thật.
- Chưa triển khai lên Vercel/FPT Cloud và chưa kiểm thử tải đồng thời.
- Không chuyển dữ liệu hoặc tài khoản từ bản Sites cũ.
- Cần điền cấu hình database/domain của chủ sở hữu trước khi sử dụng production.
