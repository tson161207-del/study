import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {getPool} from '../lib/db.mjs';
// Run only against a disposable test database and its running test application.
if(process.env.ALLOW_INTEGRATION_TEST!=='1')throw Error('Set ALLOW_INTEGRATION_TEST=1 only for a disposable test database.');
const origin=process.env.APP_URL||'http://localhost:3000';
const email='test-'+randomUUID()+'@example.test';
let cookie='';
async function call(path,body){
 const r=await fetch(origin+path,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookie},body:body?JSON.stringify(body):undefined});
 if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];
 return {status:r.status,data:await r.json()};
}
try{
 assert.equal((await call('/api/auth/register',{email,name:'Integration',password:'test-password-12345'})).status,201);
 const saved=await call('/api/library',{title:'Temporary test',group:'THPT',subject:'Toán',latex:'$1+1$',duration:10});
 assert.equal(saved.status,200);
 assert.equal((await call('/api/library')).data.exams.length,1);
 assert.equal((await call('/api/library',{action:'delete',id:saved.data.id})).status,200);
 assert.equal((await call('/api/auth/logout',{})).status,200);
 assert.equal((await call('/api/library')).data.user,null);
 assert.equal((await call('/api/auth/login',{email,password:'test-password-12345'})).status,200);
 console.log('HTTP integration passed.');
}finally{
 const db=getPool();await db.query('DELETE FROM users WHERE email=$1',[email]);await db.end();
}
