import test from 'node:test';
import assert from 'node:assert/strict';
import {hashPassword,verifyPassword,normalizeEmail,validateExam,checkOrigin,readJson} from '../lib/core.mjs';
import {sessionCookie} from '../lib/auth.mjs';
test('Passwords are salted and verified without storing plaintext',async()=>{
 const password='test-password-123';
 const a=await hashPassword(password), b=await hashPassword(password);
 assert.notEqual(a,b);assert.ok(!a.includes(password));
 assert.equal(await verifyPassword(password,a),true);
 assert.equal(await verifyPassword('wrong-password',a),false);
 assert.equal(await verifyPassword(password,'broken'),false);
});
test('Reject forged origins and malformed/oversized data',async()=>{
 process.env.APP_URL='https://study.example.com';
 assert.throws(()=>checkOrigin(new Request('https://study.example.com/api/library',{headers:{origin:'https://evil.example'}})));
 assert.doesNotThrow(()=>checkOrigin(new Request('https://study.example.com/api/library',{headers:{origin:'https://study.example.com'}})));
 assert.equal(normalizeEmail(' Me@Example.com '),'me@example.com');
 assert.throws(()=>normalizeEmail('x'));
 assert.throws(()=>validateExam({title:'A',group:'THPT',subject:'Invalid',latex:'x',duration:30}));
 assert.throws(()=>validateExam({title:'A',group:'THPT',subject:'Toán',latex:'x',duration:0}));
 await assert.rejects(readJson(new Request('http://localhost',{method:'POST',body:'x'.repeat(100)}),20));
 await assert.rejects(readJson(new Request('http://localhost',{method:'POST',body:'[]'})));
});
test('Production cookies are HttpOnly and Secure',()=>{
 const old=process.env.NODE_ENV;process.env.NODE_ENV='production';
 const cookie=sessionCookie('abc');
 assert.match(cookie,/HttpOnly/);assert.match(cookie,/SameSite=Lax/);assert.match(cookie,/Secure/);
 if(old===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=old;
});
