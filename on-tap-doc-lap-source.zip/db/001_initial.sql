CREATE TABLE IF NOT EXISTS users (
 id uuid PRIMARY KEY,
 email varchar(254) NOT NULL UNIQUE,
 name varchar(80) NOT NULL,
 password_hash text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash char(64) PRIMARY KEY,
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS exams (
 id uuid PRIMARY KEY,
 owner uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title varchar(160) NOT NULL,
 exam_group text NOT NULL CHECK (exam_group IN ('THPT','HSA','TSA')),
 subject text NOT NULL,
 latex text NOT NULL CHECK (length(latex)<=200000),
 duration integer NOT NULL CHECK (duration BETWEEN 1 AND 300),
 created bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS exams_owner_idx ON exams(owner,created DESC);
CREATE TABLE IF NOT EXISTS auth_limits (
 key_hash char(64) NOT NULL,
 bucket bigint NOT NULL,
 attempts integer NOT NULL DEFAULT 1,
 PRIMARY KEY(key_hash,bucket)
);
