# Ôn Tập — bản mã nguồn độc lập

Ứng dụng Next.js + PostgreSQL, triển khai trên Vercel hoặc máy chủ FPT Cloud. Không dùng Sites, Cloudflare D1, đăng nhập ChatGPT hay khóa OpenAI. Bạn sở hữu mã nguồn, tài khoản hosting và cơ sở dữ liệu.

## Chức năng
- THPT: Toán, Vật lý, Hóa học, Sinh học, Lịch sử, Địa lý, Ngữ văn, Tiếng Anh.
- HSA và TSA: các nhóm kiến thức riêng.
- Đăng ký/đăng nhập bằng email và mật khẩu; sửa tên, đăng xuất.
- Mật khẩu băm scrypt có salt; phiên ngẫu nhiên được băm trong PostgreSQL, cookie HttpOnly/SameSite, Secure khi production; hạn dùng 7 ngày.
- Giới hạn số lần đăng nhập/đăng ký dùng bộ đếm PostgreSQL, hoạt động qua nhiều instance.
- Tải .tex, dán LaTeX, xem trước, lưu/sửa/xóa/tải xuống đề; tìm kiếm và đồng hồ tự luyện.
- Thư viện hiện là **riêng cho từng tài khoản**. Đề minh họa chung có sẵn trong mã. Chưa có trang quản trị hoặc chức năng phát hành đề của giáo viên cho mọi học sinh.
- MathJax chỉ hiển thị công thức và một số cấu trúc văn bản. **Không phải trình biên dịch TeX đầy đủ**; TikZ, ảnh ngoài, bảng và macro/gói tùy chỉnh có thể không hiển thị đúng.
- Chưa có xác minh email, quên mật khẩu qua email, chấm điểm tự động hoặc thu phí. Email hiện dùng làm định danh, chưa xác minh quyền sở hữu.

## Yêu cầu
Node.js 22.13+ (khuyến nghị Node 22 LTS), npm, PostgreSQL 15+.
Docker Compose v2 nếu chạy toàn bộ bằng Docker.

## Chạy trên máy cá nhân
1. Sao chép .env.example thành .env.
2. Nếu chưa có PostgreSQL: chạy lệnh dưới và đặt DATABASE_URL đúng như ví dụ.
3. Cài thư viện, tạo bảng, chạy ứng dụng.

    docker compose -f compose.dev.yaml up -d
    npm ci

Trong .env:

    DATABASE_URL=postgresql://ontap:local_dev_password@localhost:5432/ontap
    APP_URL=http://localhost:3000

Sau đó:

    npm run db:migrate
    npm run dev

Mở http://localhost:3000. Đăng ký tài khoản đầu tiên bằng biểu mẫu. Không có tài khoản/mật khẩu mặc định. Không dùng mật khẩu thử nghiệm cho production.

## Vercel
1. Tạo PostgreSQL trên dịch vụ của bạn (ví dụ nhà cung cấp có kết nối PostgreSQL tương thích). Chọn vùng cơ sở dữ liệu gần vùng chạy ứng dụng.
2. Giải nén mã nguồn, đưa vào GitHub/GitLab của bạn; không tải .env, node_modules hoặc .next lên Git.
3. Import repository vào Vercel, chọn framework Next.js và Node 22.x. vercel.json đã khai báo npm ci và npm run build.
4. Thiết lập Environment Variables:
   - DATABASE_URL: URL PostgreSQL **pooled** từ nhà cung cấp, với TLS theo hướng dẫn của họ.
   - APP_URL: URL chính xác của website, ví dụ https://ten-web.vercel.app (không kèm đường dẫn).
   - DB_POOL_MAX: 3 để khởi đầu; điều chỉnh theo giới hạn kết nối cơ sở dữ liệu.
5. Trên máy của bạn, điền DATABASE_URL hoặc MIGRATION_DATABASE_URL (direct connection) vào .env rồi chạy:

       npm ci
       npm run db:migrate

   Script migration tạo bảng trong PostgreSQL đích, không chạy trên filesystem tạm của Vercel. Chỉ chạy bằng người có quyền quản lý database. Chạy lại an toàn vì có bảng theo dõi migration và khóa giao dịch.
6. Deploy. Nếu chỉ biết tên miền sau lần Deploy đầu, đặt APP_URL rồi Redeploy.
7. Mở URL và thử đăng ký, đăng xuất, đăng nhập, thêm đề, tải lại trang. API thay đổi dữ liệu sẽ từ chối nếu APP_URL không khớp Origin.
8. Preview deployment cần APP_URL riêng và database thử nghiệm riêng. Không trỏ tùy tiện preview vào database production.

Không lưu PostgreSQL hoặc đề thi vào ổ đĩa Vercel. Bản này lưu nội dung .tex trong PostgreSQL. Nếu thêm ảnh/PDF lớn về sau, dùng object storage do bạn quản lý.
Không tự chạy migration trong build để tránh các bản preview thay đổi database production.
Vercel không dùng Dockerfile; triển khai Next.js trực tiếp.

## FPT Cloud — máy ảo Linux
Hướng dẫn này dành cho **máy ảo FPT Cloud có quyền cài Docker**, không phải mọi dịch vụ PaaS của FPT.

1. Tạo máy ảo Ubuntu, cài Docker Engine và Compose plugin theo hướng dẫn chính thức của Docker. Gợi ý khởi đầu 2 vCPU, 4 GB RAM để build trên máy; đây không phải cam kết tải đồng thời. Có thể build image trong CI rồi đưa lên máy ít RAM hơn.
2. Trỏ bản ghi DNS A của domain tới IP public máy ảo. Mở inbound TCP 80/443; giới hạn SSH theo IP quản trị. Không mở cổng PostgreSQL 5432 ra Internet.
3. Tải mã nguồn lên server. Tạo .env từ .env.example, đặt:

       POSTGRES_PASSWORD=chuoiNGauNhienRatDaiChiChuVaSo
       DOMAIN=ontap.tenmiencuaban.vn

   DOMAIN chỉ gồm hostname, không có https:// hay dấu /. Mật khẩu mẫu ở trên phải được thay bằng chuỗi ngẫu nhiên riêng. Compose tự đặt DATABASE_URL và APP_URL cho container.
4. Chạy:

       docker compose up -d --build
       docker compose ps
       docker compose logs --tail=100 migrate app proxy

5. Caddy tự cấp HTTPS khi DNS và cổng 80/443 hoạt động đúng. Mở https://DOMAIN đã đặt.
6. PostgreSQL nằm trong volume postgres_data. Volume vẫn còn khi khởi động lại container. **Không chạy docker compose down -v nếu muốn giữ dữ liệu.**
7. Khi cập nhật mã nguồn, sao lưu database trước rồi:

       docker compose build migrate
       docker compose run --rm migrate
       docker compose up -d --force-recreate app proxy

   Migration hoàn tất trước khi app mới được khởi động. Nếu chỉ chạy một máy ảo thì cách cập nhật này có thể gây gián đoạn ngắn.

Trong production, cookie luôn Secure nên cần truy cập HTTPS, không thử đăng nhập bằng http://IP:3000.
Caddy chỉ chuyển tiếp vào mạng Docker nội bộ và ghi đè X-Real-IP để bộ giới hạn IP không tin header tùy ý của người dùng.

## Sao lưu, khôi phục và dọn dẹp
Trên FPT Cloud, ví dụ sao lưu từ shell Linux:

    docker compose exec -T db pg_dump -U ontap -d ontap -Fc > ontap-backup.dump

Cất bản sao ở nơi khác máy chủ, mã hóa và định kỳ kiểm tra khôi phục. Volume trên một máy không thay thế bản sao lưu.

Khôi phục **vào database thử nghiệm/trống**, không ghi đè production khi chưa có kế hoạch:

    docker compose exec -T db pg_restore -U ontap -d ontap --no-owner < ontap-backup.dump

Dọn phiên và bộ đếm cũ hằng ngày bằng cron của bạn:

    docker compose exec -T app node scripts/cleanup.mjs

Trên Vercel, chạy npm run db:cleanup từ một job quản trị có DATABASE_URL. Chưa cấu hình dịch vụ gửi email hoặc lịch tự động thay cho bạn.

## Kiểm thử
    npm test
    npm run typecheck
    npm run build

npm test dùng PostgreSQL nhúng PGlite chỉ trong kiểm thử: đăng ký, đăng nhập, mật khẩu sai, phiên hết hạn/thu hồi, CRUD, phân quyền giữa hai tài khoản, giới hạn đăng nhập, CSRF và giới hạn payload. PGlite không được dùng trong ứng dụng production.

Muốn kiểm thử HTTP end-to-end với PostgreSQL thật: khởi động ứng dụng và một **database thử nghiệm riêng**, đặt ALLOW_INTEGRATION_TEST=1 trong môi trường test rồi chạy npm run test:integration. Script tạo và xóa một tài khoản thử nghiệm. Không chạy trên database của người dùng thật.

Chưa thử nghiệm tải cao hoặc triển khai vào tài khoản Vercel/FPT của bạn. Số người dùng đồng thời phụ thuộc gói hosting, CPU/RAM, giới hạn hàm và database. Phải đo tải trước khi cam kết số lượng.

## Cấu trúc
- app/study-app.tsx: giao diện và trình nhập đề.
- app/api/auth/: đăng ký, đăng nhập, đăng xuất.
- app/api/library/: API thư viện.
- lib/: xác thực, phân quyền, PostgreSQL và kiểm tra dữ liệu.
- db/: migration SQL.
- scripts/: migration và dọn dữ liệu hết hạn.
- Dockerfile, compose.yaml, Caddyfile: FPT Cloud/Linux.
- vercel.json: Vercel.

Các file .env, cơ sở dữ liệu, dữ liệu người dùng từ bản Sites cũ và node_modules không nằm trong gói mã nguồn.
Tài khoản của bản Sites cũ không được chuyển sang; người dùng đăng ký mới trên bản độc lập.
Giao diện tải font Google Fonts và bộ hiển thị MathJax từ CDN công khai; có thể tự host các asset này nếu cần mạng nội bộ.

## Tài liệu tham khảo chính thức
- Next.js deployment: https://nextjs.org/docs/app/getting-started/deploying
- Vercel environment variables: https://vercel.com/docs/environment-variables
- Docker Next.js guide: https://docs.docker.com/guides/nextjs/
- Docker Engine Ubuntu: https://docs.docker.com/engine/install/ubuntu/
- node-postgres connection pooling: https://node-postgres.com/features/pooling
