import {checkOrigin,json,failure,digest} from '../../../../lib/core.mjs';
import {sessionToken,sessionCookie} from '../../../../lib/auth.mjs';
import {getPool} from '../../../../lib/db.mjs';
export const runtime='nodejs';
export async function POST(req:Request){try{checkOrigin(req);const token=sessionToken(req);if(token)await getPool().query('DELETE FROM sessions WHERE token_hash=$1',[digest(token)]);const response=json({ok:true});response.headers.set('Set-Cookie',sessionCookie('',0));return response}catch(e){return failure(e)}}
