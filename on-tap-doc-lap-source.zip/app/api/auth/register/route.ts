import {checkOrigin,readJson,json,failure} from '../../../../lib/core.mjs';
import {authenticate,sessionCookie} from '../../../../lib/auth.mjs';
export const runtime='nodejs';
export async function POST(req:Request){try{checkOrigin(req);const b=await readJson(req,8192);const {user,token}=await authenticate(req,b,true);const response=json({user},201);response.headers.set('Set-Cookie',sessionCookie(token));return response}catch(e){return failure(e)}}
