import {checkOrigin,readJson,json,failure} from '../../../lib/core.mjs';
import {readLibrary,writeLibrary} from '../../../lib/library.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{return json(await readLibrary(req))}catch(e){return failure(e)}}
export async function POST(req:Request){try{checkOrigin(req);return json(await writeLibrary(req,await readJson(req)))}catch(e){return failure(e)}}
