import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Ôn Tập — Mỗi ngày một bước tiến', description: 'Không gian ôn tập THPT, HSA và TSA. Thư viện đề LaTeX của bạn.' };
export default function Layout({children}: {children: React.ReactNode}) { return <html lang="vi"><body>{children}</body></html>; }
