"use client";
import {useEffect,useRef,useState} from 'react';
import {BookOpen,LayoutDashboard,Library,Upload,ArrowUpRight,ArrowRight,Search,Plus,Clock,FileText,ChevronRight,X,Download,Play,Check,GraduationCap,Sparkles,Atom,FlaskConical,Dna,Globe,Landmark,Languages,PenTool,Calculator,LogOut,Menu,Trash2,Pencil} from 'lucide-react';
type Exam={id:string;title:string;group:string;subject:string;latex:string;duration:number;created?:number};
const groups:Record<string,string[]>={THPT:['Toán','Vật lý','Hóa học','Sinh học','Lịch sử','Địa lý','Ngữ văn','Tiếng Anh'],HSA:['Tư duy định lượng','Tư duy định tính','Khoa học'],TSA:['Tư duy toán học','Tư duy đọc hiểu','Tư duy khoa học']};
const icons=[Calculator,Atom,FlaskConical,Dna,Landmark,Globe,PenTool,Languages];
const descriptions=['Hàm số, đại số & hình học','Cơ học, điện & sóng','Hữu cơ & vô cơ','Di truyền & sinh thái','Việt Nam & thế giới','Tự nhiên & kinh tế xã hội','Đọc hiểu & nghị luận','Ngữ pháp & đọc hiểu'];
const sample=String.raw`\section{Ôn tập hàm số}
Câu 1. Tìm đạo hàm của hàm số $f(x)=x^3-3x+2$.
A. $3x^2-3$     B. $x^2-3$     C. $3x^2+3$     D. $3x-3$

Câu 2. Tính tích phân:
\[
I=\int_0^1 (2x+1)\,dx.
\]

Câu 3. Giải phương trình $\log_2(x-1)=3$.

\section{Đáp án tham khảo}
1. A. Ta có $f'(x)=3x^2-3$.
2. $I=[x^2+x]_0^1=2$.
3. $x-1=2^3=8$, suy ra $x=9$.
`;
const demos:Exam[]=[
{id:'demo1',title:'Hàm số & những bài toán nền tảng',group:'THPT',subject:'Toán',duration:30,latex:sample},
{id:'demo2',title:'Chuyển động thẳng — Khởi động',group:'THPT',subject:'Vật lý',duration:20,latex:String.raw`\section{Chuyển động thẳng}
Câu 1. Một vật chuyển động đều với $v=10\,m/s$. Tính quãng đường đi được sau $t=15\,s$.

Câu 2. Vật xuất phát từ trạng thái nghỉ với gia tốc $a=2\,m/s^2$. Tính vận tốc sau 5 giây.

\section{Đáp án tham khảo}
1. $s=vt=150\,m$.
2. $v=at=10\,m/s$.`},
{id:'demo3',title:'Tư duy định lượng — Bài luyện mở đầu',group:'HSA',subject:'Tư duy định lượng',duration:20,latex:String.raw`\section{Tư duy định lượng}
Câu 1. Một sản phẩm giá 200.000 đồng được giảm 15%. Giá mới là bao nhiêu?

Câu 2. Dãy số $2,5,8,11,\ldots$ có số hạng thứ 20 bằng bao nhiêu?

\section{Đáp án tham khảo}
1. 170.000 đồng.
2. $a_{20}=2+19\times3=59$.`},
{id:'demo4',title:'Tư duy toán học — Làm quen',group:'TSA',subject:'Tư duy toán học',duration:20,latex:String.raw`\section{Tư duy toán học}
Câu 1. Hộp có 3 bi đỏ và 2 bi xanh. Chọn ngẫu nhiên một bi. Xác suất chọn được bi đỏ?

Câu 2. Tìm giá trị nhỏ nhất của $f(x)=(x-2)^2+3$.

\section{Đáp án tham khảo}
1. $P=\frac{3}{5}$.
2. Giá trị nhỏ nhất là 3, đạt tại $x=2$.`}
];
function Preview({latex}:{latex:string}){
 const ref=useRef<HTMLDivElement>(null);const [error,setError]=useState('');
 useEffect(()=>{let dead=false; const render=async()=>{const w=window as any;try{for(let i=0;i<30&&!w.MathJax?.startup?.promise&&!dead;i++)await new Promise(r=>setTimeout(r,300));if(w.MathJax?.startup?.promise)await w.MathJax.startup.promise;if(dead||!ref.current)return;if(w.MathJax?.typesetPromise){w.MathJax.typesetClear?.([ref.current]);await w.MathJax.typesetPromise([ref.current]);}else setError('Đang tải bộ hiển thị công thức. Nếu mạng chặn CDN, nội dung LaTeX vẫn hiển thị dạng văn bản.');}catch{setError('Một số công thức chưa hiển thị được. Kiểm tra cú pháp LaTeX.');}};const t=setTimeout(render,700);return()=>{dead=true;clearTimeout(t)}},[latex]);
 let content=latex.includes('\\begin{document}')?latex.split('\\begin{document}')[1].split('\\end{document}')[0]:latex;
 content=content.replace(/\\(?:sub)*section\*?\{([^}]*)\}/g,'\n$1\n').replace(/\\text(?:bf|it)\{([^}]*)\}/g,'$1').replace(/\\begin\{(?:enumerate|itemize)\}|\\end\{(?:enumerate|itemize)\}/g,'').replace(/\\item\s*/g,'\n• ');
 return <><div className="paper-text" ref={ref} key={latex}>{content}</div>{error&&<small className="muted">{error}</small>}</>;
}
export default function StudyApp(){
 const [group,setGroup]=useState('THPT'),[view,setView]=useState('home'),[subject,setSubject]=useState('Tất cả'),[query,setQuery]=useState(''),[user,setUser]=useState<any>(null),[exams,setExams]=useState<Exam[]>([]),[loading,setLoading]=useState(true),[notice,setNotice]=useState(''),[editor,setEditor]=useState<Exam|null>(null),[opened,setOpened]=useState<Exam|null>(null),[auth,setAuth]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[authError,setAuthError]=useState(''),[name,setName]=useState(''),[busy,setBusy]=useState(false),[running,setRunning]=useState(false),[seconds,setSeconds]=useState(0),[mobile,setMobile]=useState(false),[confirmDelete,setConfirmDelete]=useState<Exam|null>(null);
 async function load(){try{const r=await fetch('/api/library');if(!r.ok)throw Error('Chưa tải được thư viện. Vui lòng thử lại.');const d:any=await r.json();setUser(d.user);setExams(d.exams);setName(d.user?.name||'')}catch(e){setNotice((e as Error).message)}finally{setLoading(false)}}
 useEffect(()=>{load();const w=window as any;w.MathJax={loader:{load:['ui/safe']},tex:{inlineMath:[['$','$'],['\\(','\\)']],displayMath:[['$$','$$'],['\\[','\\]']]},options:{enableMenu:false},startup:{typeset:false}};const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-chtml.js';s.async=true;s.onload=()=>setNotice('');document.head.appendChild(s);return()=>{s.remove()}},[]);
 useEffect(()=>{if(!running)return;const t=setInterval(()=>setSeconds(s=>{if(s<=1){setRunning(false);return 0}return s-1}),1000);return()=>clearInterval(t)},[running]);
 useEffect(()=>{if(!notice)return;const t=setTimeout(()=>setNotice(''),7000);return()=>clearTimeout(t)},[notice]);
 async function post(data:any){const r=await fetch('/api/library',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d:any=await r.json();if(!r.ok)throw Error(d.error||'Thao tác chưa thành công');return d}
 function navigate(g:string){setGroup(g);setSubject('Tất cả');setQuery('');setView('home');setMobile(false)}
 function create(){setEditor({id:'',title:'',group,subject:groups[group][0],duration:45,latex:''});setMobile(false)}
 async function save(){if(!editor)return;setBusy(true);try{await post({...editor,id:editor.id.startsWith('demo')?'':editor.id});await load();setEditor(null);setView('library');setNotice('Đã lưu đề vào thư viện của bạn.')}catch(e){setNotice((e as Error).message)}finally{setBusy(false)}}
 function download(e:Exam){const a=document.createElement('a');const url=URL.createObjectURL(new Blob([e.latex],{type:'text/plain;charset=utf-8'}));a.href=url;a.download=e.title.replace(/[^\p{L}\p{N} -]/gu,'')+'.tex';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
 const list=(view==='library'?exams:[...exams,...demos]).filter(e=>e.group===group&&(subject==='Tất cả'||e.subject===subject)&&(!query||(e.title+' '+e.subject).toLocaleLowerCase('vi').includes(query.toLocaleLowerCase('vi'))));
 return <div className="shell">
 <aside className={mobile?'sidebar show':'sidebar'}>
  <a className="brand" href="/"><span className="brand-icon"><BookOpen size={23}/></span>ôn tập<span className="brand-dot">.</span></a>
  <div className="nav-label">KHÔNG GIAN HỌC TẬP</div>
  <button className={view==='home'?'nav active':'nav'} onClick={()=>{setView('home');setMobile(false)}}><LayoutDashboard size={19}/>Tổng quan</button>
  <button className={view==='library'?'nav active':'nav'} onClick={()=>{setView('library');setMobile(false)}}><Library size={19}/>Thư viện của tôi<span className="nav-count">{exams.length}</span></button>
  <div className="nav-label">CHƯƠNG TRÌNH ÔN TẬP</div>
  {Object.keys(groups).map((g,i)=><button className={'nav program '+(group===g?'selected':'')} key={g} onClick={()=>navigate(g)}><span className={'mini-icon c'+i}>{i===0?'12':i===1?'H':'T'}</span><span>{g}<small>{['Tốt nghiệp THPT','Đánh giá năng lực','Đánh giá tư duy'][i]}</small></span><ChevronRight size={15}/></button>)}
  <div className="sidebar-bottom"><div className="import-promo"><span className="small-icon"><FileText size={19}/></span><h4>Đề của bạn, cách học của bạn.</h4><p>Tải đề LaTeX lên và bắt đầu ôn tập ngay.</p><button onClick={create}>Tạo đề mới <Plus size={16}/></button></div><div className="side-foot"><span className="online-dot"/>Học từng chút. Tiến từng ngày.</div></div>
 </aside>
 <div className="workspace">
 <header className="topbar"><div className="breadcrumb"><button className="mobile-toggle icon-button" aria-label="Mở menu" onClick={()=>setMobile(!mobile)}><Menu size={21}/></button>Không gian học tập <ChevronRight size={14}/><strong>{view==='home'?'Tổng quan':'Thư viện của tôi'}</strong></div><div className="account">{user?<><button className="profile" onClick={()=>setAuth('profile')}><span className="avatar">{user.name.slice(0,1).toUpperCase()}</span><span>{user.name}</span></button><button className="icon-button" aria-label="Đăng xuất" onClick={async()=>{try{const r=await fetch("/api/auth/logout",{method:"POST"});if(!r.ok)throw Error("Chưa đăng xuất được.");setUser(null);setExams([]);setNotice("Đã đăng xuất.");}catch(e){setNotice((e as Error).message)}}}><LogOut size={17}/></button></>:<><button className="text-button" onClick={()=>setAuth('login')}>Đăng nhập</button><button className="btn small" onClick={()=>setAuth('register')}>Đăng ký <ArrowUpRight size={14}/></button></>}</div></header>
 <main>
  <div className="heading-row"><div><div className="eyebrow">HÔM NAY LÀ MỘT KHỞI ĐẦU TỐT</div><h1>{view==='home'?'Mỗi ngày, một bước tiến.':'Thư viện của bạn.'}</h1><p className="subtitle">{view==='home'?'Chọn mục tiêu, tìm môn học và bắt đầu hành trình của bạn.':'Những đề ôn tập được bạn lưu lại, trong một không gian riêng.'}</p></div><button className="btn" onClick={create}><Plus size={18}/>Tải đề LaTeX</button></div>
  {view==='home'&&<><section className="hero"><div className="hero-content"><span className="pill"><span/>KHÔNG GIAN CHO SỰ TẬP TRUNG</span><h2>Vững kiến thức.<br/>Tự tin chinh phục kỳ thi.</h2><p>THPT, HSA hay TSA — mỗi mục tiêu đều<br className="desktop"/> bắt đầu từ một buổi học hôm nay.</p><button className="btn white" onClick={()=>document.getElementById('subjects')?.scrollIntoView({behavior:'smooth'})}>Bắt đầu ôn tập <ArrowRight size={17}/></button></div><div className="hero-art" aria-hidden="true"><div className="orbit one"/><div className="orbit two"/><span className="math m1">x² + y²</span><span className="math m2">∑</span><span className="math m3">√x</span><div className="study-card back"><div/><div/><div/></div><div className="study-card front"><div className="art-book"><BookOpen size={48}/></div><span>KIẾN THỨC LÀ HÀNH TRANG</span><strong>Sẵn sàng<br/>cho ngày mai.</strong><div className="art-line"/><div className="art-line short"/></div><div className="floating-check"><Check size={19}/>Thêm một điều đã hiểu</div><Sparkles className="spark" size={28}/></div></section>
  <div className="section-heading" id="subjects"><div><h2>Bạn đang hướng đến kỳ thi nào?</h2><p>Không gian ôn tập phù hợp với mục tiêu của bạn.</p></div><span className="quiet-label">03 CHƯƠNG TRÌNH</span></div>
  <div className="tracks">{Object.keys(groups).map((g,i)=><button className={'track '+(group===g?'current':'')} key={g} onClick={()=>navigate(g)}><span className={'track-icon c'+i}>{i===0?<GraduationCap/>:i===1?<BookOpen/>:<Atom/>}</span><div><h3>{g}<span>{['Tốt nghiệp THPT','Đánh giá năng lực','Đánh giá tư duy'][i]}</span></h3><p>{groups[g].length} {i===0?'môn học':'nhóm kiến thức'} · Học theo mục tiêu</p></div><span className="radio">{group===g&&<span/>}</span></button>)}</div>
  <div className="section-heading"><div><h2>Khám phá môn học <span className="tag">{group}</span></h2><p>Chọn một môn, bắt đầu một bước tiến mới.</p></div><button className="text-link" onClick={()=>{setSubject('Tất cả');document.getElementById('exams')?.scrollIntoView({behavior:'smooth'})}}>Xem đề ôn tập <ArrowRight size={16}/></button></div>
  <div className="subjects">{groups[group].map((s,i)=>{const Icon=icons[i%8];return <button key={s} className={'subject '+(subject===s?'chosen':'')} onClick={()=>{setSubject(s);document.getElementById('exams')?.scrollIntoView({behavior:'smooth'})}}><div className={'subject-icon color'+i}><Icon size={24}/></div><h3>{s}</h3><p>{group==='THPT'?descriptions[i]:'Luyện kỹ năng & củng cố kiến thức'}</p><div className="subject-bottom"><span>{[...exams,...demos].filter(e=>e.group===group&&e.subject===s).length} đề ôn tập</span><ArrowUpRight size={17}/></div></button>})}</div></>}
  <section id="exams"><div className="section-heading"><div><h2>{view==='library'?'Đề đã lưu':'Bắt đầu với một đề ôn tập'}</h2><p>{view==='library'?'Đề được lưu trên tài khoản, có thể mở lại trên thiết bị khác.':'Các đề minh họa ngắn để làm quen, cùng đề bạn tự tải lên.'}</p></div>{view==='library'&&<select value={group} onChange={e=>{setGroup(e.target.value);setSubject('Tất cả')}}>{Object.keys(groups).map(g=><option key={g}>{g}</option>)}</select>}</div>
  <div className="filters"><div className="chips"><button className={subject==='Tất cả'?'chip active':'chip'} onClick={()=>setSubject('Tất cả')}>Tất cả</button>{groups[group].map(s=><button className={subject===s?'chip active':'chip'} key={s} onClick={()=>setSubject(s)}>{s}</button>)}</div><label className="search"><Search size={17}/><input aria-label="Tìm đề thi" placeholder="Tìm tên đề…" value={query} onChange={e=>setQuery(e.target.value)}/></label></div>
  {loading&&<p className="muted">Đang tải thư viện…</p>}
  <div className="exam-grid">{list.map(e=><article className="exam-card" key={e.id}><div className="exam-top"><span className="tag">{e.subject}</span><span className="muted">{e.id.startsWith('demo')?'ĐỀ MINH HỌA':'ĐỀ CỦA BẠN'}</span></div><h3>{e.title}</h3><p><Clock size={15}/>{e.duration} phút<span>•</span><FileText size={15}/>LaTeX</p><div className="exam-bottom"><button className="text-link" onClick={()=>{setOpened(e);setSeconds(e.duration*60);setRunning(false)}}>Mở đề ôn tập <ArrowRight size={16}/></button>{!e.id.startsWith('demo')&&<div><button className="icon-button" aria-label={'Sửa '+e.title} onClick={()=>setEditor({...e})}><Pencil size={16}/></button><button className="icon-button" aria-label={'Xóa '+e.title} onClick={()=>setConfirmDelete(e)}><Trash2 size={16}/></button></div>}</div></article>)}</div>
  {!loading&&!list.length&&<div className="empty"><Library size={34}/><h3>{query?'Chưa tìm thấy đề phù hợp':'Một thư viện mới đang chờ bạn'}</h3><p>{query?'Thử tên đề khác hoặc thay đổi bộ lọc.':'Tải đề LaTeX đầu tiên cho môn học này để bắt đầu.'}</p><button className="btn" onClick={create}><Plus size={16}/>Thêm đề ôn tập</button></div>}
  </section><footer><a className="footer-brand" href="/">ôn tập.</a><span>Một không gian nhỏ. Những mục tiêu lớn.</span><span>THPT · HSA · TSA</span></footer>
 </main></div>
 {notice&&<div className="toast" role="status">{notice}<button aria-label="Đóng thông báo" onClick={()=>setNotice('')}><X size={16}/></button></div>}
 {auth&&<div className="overlay"><section className="modal auth-modal" role="dialog" aria-modal="true" aria-label="Tài khoản"><button className="close icon-button" aria-label="Đóng" onClick={()=>{setAuth('');setAuthError('');setPassword('')}}><X/></button><span className="auth-logo"><GraduationCap size={32}/></span><h2>{user?'Hồ sơ học tập':auth==='register'?'Bắt đầu hành trình của bạn':'Chào mừng bạn trở lại'}</h2><p>{user?'Đặt tên để cá nhân hóa không gian ôn tập.':'Tài khoản của bạn, thư viện đề của bạn.'}</p>
 <form onSubmit={async e=>{e.preventDefault();setBusy(true);setAuthError('');try{
 if(user){await post({action:'profile',name});}else{
 const r=await fetch('/api/auth/'+(auth==='register'?'register':'login'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,name})});const d=await r.json();if(!r.ok)throw Error(d.error||'Không thể đăng nhập.');
 }
 await load();setPassword('');setAuth('');setNotice(user?'Đã lưu hồ sơ.':'Bạn đã đăng nhập thành công.');
 }catch(e){setAuthError((e as Error).message)}finally{setBusy(false)}}}>
 {(user||auth==='register')&&<label>Tên hiển thị<input required maxLength={80} autoComplete="name" value={name} onChange={e=>setName(e.target.value)}/></label>}
 {!user&&<><label>Email<input required type="email" maxLength={254} autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Mật khẩu<input required type="password" minLength={10} maxLength={128} autoComplete={auth==='register'?'new-password':'current-password'} placeholder="Tối thiểu 10 ký tự" value={password} onChange={e=>setPassword(e.target.value)}/></label></>}
 {user&&<p className="muted">{user.email}</p>}
 {authError&&<p className="auth-error" role="alert">{authError}</p>}
 <button disabled={busy} className="btn full">{busy?'Đang xử lý…':user?'Lưu hồ sơ':auth==='register'?'Tạo tài khoản':'Đăng nhập'}</button>
 </form>
 {!user&&<button className="auth-switch text-link" onClick={()=>{setAuth(auth==='register'?'login':'register');setAuthError('');setPassword('')}}>{auth==='register'?'Đã có tài khoản? Đăng nhập':'Chưa có tài khoản? Đăng ký'}</button>}
 </section></div>}
 {editor&&<div className="overlay"><section className="modal editor-modal" role="dialog" aria-modal="true" aria-label="Soạn đề LaTeX"><div className="modal-heading"><div><div className="eyebrow">THƯ VIỆN CỦA BẠN</div><h2>{editor.id?'Chỉnh sửa đề':'Thêm một đề ôn tập'}</h2></div><button className="icon-button" aria-label="Đóng trình soạn" onClick={()=>setEditor(null)}><X/></button></div><div className="editor-fields"><label>Tên đề<input value={editor.title} maxLength={160} placeholder="VD: Ôn tập đạo hàm — Đề số 01" onChange={e=>setEditor({...editor,title:e.target.value})}/></label><label>Kỳ thi<select value={editor.group} onChange={e=>setEditor({...editor,group:e.target.value,subject:groups[e.target.value][0]})}>{Object.keys(groups).map(g=><option key={g}>{g}</option>)}</select></label><label>Môn học<select value={editor.subject} onChange={e=>setEditor({...editor,subject:e.target.value})}>{groups[editor.group].map(s=><option key={s}>{s}</option>)}</select></label><label>Phút<input type="number" min="1" max="300" value={editor.duration} onChange={e=>setEditor({...editor,duration:Number(e.target.value)})}/></label></div><div className="editor-tools"><label className="upload-button"><Upload size={16}/>Chọn tệp .tex<input hidden type="file" accept=".tex,.txt" onChange={async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>200000){setNotice('Tệp tối đa 200 KB.');return}setEditor({...editor,latex:await f.text(),title:editor.title||f.name.replace(/\.(tex|txt)$/i,'')})}}/></label><button className="text-link" onClick={()=>setEditor({...editor,latex:sample,title:editor.title||'Ôn tập hàm số'})}>Chèn mẫu LaTeX</button><span>Lưu nguyên bản mã nguồn • Không cần sửa code web</span></div><div className="split-editor"><div><div className="pane-title">MÃ LATEX<span>{editor.latex.length.toLocaleString()} ký tự</span></div><textarea spellCheck={false} aria-label="Mã LaTeX" placeholder="Dán nội dung đề và công thức LaTeX vào đây…" value={editor.latex} onChange={e=>setEditor({...editor,latex:e.target.value})}/></div><div><div className="pane-title">XEM TRƯỚC<span><span className="online-dot"/>Trực tiếp</span></div><div className="preview-paper">{editor.latex?<Preview latex={editor.latex}/>:<div className="preview-empty"><FileText size={38}/><p>Đề của bạn sẽ xuất hiện tại đây</p></div>}</div></div></div><p className="support-note">Hỗ trợ văn bản, công thức LaTeX, section và danh sách cơ bản. Đây là trình hiển thị MathJax, không phải trình biên dịch TeX đầy đủ; TikZ, ảnh ngoài và các gói tùy chỉnh chưa được hỗ trợ.</p><div className="modal-actions"><button className="btn secondary" onClick={()=>download(editor)}><Download size={16}/>Tải .tex</button>{!user?<button className="btn" onClick={()=>setAuth('login')}>Đăng nhập để lưu</button>:<button className="btn" disabled={busy||!editor.title.trim()||!editor.latex.trim()} onClick={save}>{busy?'Đang lưu…':'Lưu vào thư viện'}<Check size={17}/></button>}</div></section></div>}
 {opened&&<div className="overlay"><section className="modal reader-modal" role="dialog" aria-modal="true" aria-label="Đọc đề"><div className="modal-heading"><div><span className="tag">{opened.group} · {opened.subject}</span><h2>{opened.title}</h2></div><button className="icon-button" aria-label="Đóng đề" onClick={()=>{setOpened(null);setRunning(false)}}><X/></button></div><div className="reader-toolbar"><span><Clock size={18}/><strong>{Math.floor(seconds/60).toString().padStart(2,'0')}:{(seconds%60).toString().padStart(2,'0')}</strong></span><button className="btn small" onClick={()=>{if(seconds===0)setSeconds(opened.duration*60);setRunning(!running)}}><Play size={14}/>{running?'Tạm dừng':seconds===0?'Luyện lại':'Bắt đầu / Tiếp tục'}</button><button className="icon-button" aria-label="Tải đề LaTeX" onClick={()=>download(opened)}><Download size={18}/></button></div><p className="support-note">Chế độ tự luyện: làm bài trên giấy và đối chiếu đáp án nếu đề có cung cấp. Website chưa chấm điểm tự động.</p>{seconds===0&&<div className="time-up" role="status">Đã hết thời gian ôn tập.</div>}<div className="reader-paper"><Preview latex={opened.latex}/></div></section></div>}
 {confirmDelete&&<div className="overlay"><section className="modal auth-modal" role="dialog" aria-modal="true" aria-label="Xác nhận xóa"><h2>Xóa đề khỏi thư viện?</h2><p>{confirmDelete.title}</p><div className="modal-actions"><button className="btn secondary" onClick={()=>setConfirmDelete(null)}>Giữ lại</button><button className="btn" disabled={busy} onClick={async()=>{setBusy(true);try{await post({action:'delete',id:confirmDelete.id});setConfirmDelete(null);await load();setNotice('Đã xóa đề.')}catch(e){setNotice((e as Error).message)}finally{setBusy(false)}}}>Xóa đề</button></div></section></div>}
 </div>
}



